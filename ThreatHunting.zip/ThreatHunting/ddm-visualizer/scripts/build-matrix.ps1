# Generate full MITRE ATT&CK Enterprise directory structure
# Format per line: TacticFolder|TechId|TechName|sub1id:sub1name,sub2id:sub2name,...

$base = "c:\Users\apowers\Documents\Blog-Posts\ThreatHunting\ddm-visualizer\src\models"

$matrix = @(
# ═══ Reconnaissance (TA0043) ═══
"Reconnaissance|T1595|Active Scanning|T1595.001:Scanning IP Blocks,T1595.002:Vulnerability Scanning,T1595.003:Wordlist Scanning"
"Reconnaissance|T1592|Gather Victim Host Information|T1592.001:Hardware,T1592.002:Software,T1592.003:Firmware,T1592.004:Client Configurations"
"Reconnaissance|T1589|Gather Victim Identity Information|T1589.001:Credentials,T1589.002:Email Addresses,T1589.003:Employee Names"
"Reconnaissance|T1590|Gather Victim Network Information|T1590.001:Domain Properties,T1590.002:DNS,T1590.003:Network Trust Dependencies,T1590.004:Network Topology,T1590.005:IP Addresses,T1590.006:Network Security Appliances"
"Reconnaissance|T1591|Gather Victim Org Information|T1591.001:Determine Physical Locations,T1591.002:Business Relationships,T1591.003:Identify Business Tempo,T1591.004:Identify Roles"
"Reconnaissance|T1598|Phishing for Information|T1598.001:Spearphishing Service,T1598.002:Spearphishing Attachment,T1598.003:Spearphishing Link,T1598.004:Spearphishing Voice"
"Reconnaissance|T1597|Search Closed Sources|T1597.001:Threat Intel Vendors,T1597.002:Purchase Technical Data"
"Reconnaissance|T1596|Search Open Technical Databases|T1596.001:DNS Passive DNS,T1596.002:WHOIS,T1596.003:Digital Certificates,T1596.004:CDNs,T1596.005:Scan Databases"
"Reconnaissance|T1593|Search Open Websites Domains|T1593.001:Social Media,T1593.002:Search Engines,T1593.003:Code Repositories"
"Reconnaissance|T1594|Search Victim-Owned Websites|"

# ═══ Resource Development (TA0042) ═══
"ResourceDevelopment|T1583|Acquire Infrastructure|T1583.001:Domains,T1583.002:DNS Server,T1583.003:Virtual Private Server,T1583.004:Server,T1583.005:Botnet,T1583.006:Web Services,T1583.007:Serverless,T1583.008:Malvertising"
"ResourceDevelopment|T1586|Compromise Accounts|T1586.001:Social Media Accounts,T1586.002:Email Accounts,T1586.003:Cloud Accounts"
"ResourceDevelopment|T1584|Compromise Infrastructure|T1584.001:Domains,T1584.002:DNS Server,T1584.003:Virtual Private Server,T1584.004:Server,T1584.005:Botnet,T1584.006:Web Services,T1584.007:Serverless"
"ResourceDevelopment|T1587|Develop Capabilities|T1587.001:Malware,T1587.002:Code Signing Certificates,T1587.003:Digital Certificates,T1587.004:Exploits"
"ResourceDevelopment|T1585|Establish Accounts|T1585.001:Social Media Accounts,T1585.002:Email Accounts,T1585.003:Cloud Accounts"
"ResourceDevelopment|T1588|Obtain Capabilities|T1588.001:Malware,T1588.002:Tool,T1588.003:Code Signing Certificates,T1588.004:Digital Certificates,T1588.005:Exploits,T1588.006:Vulnerabilities"
"ResourceDevelopment|T1608|Stage Capabilities|T1608.001:Upload Malware,T1608.002:Upload Tool,T1608.003:Install Digital Certificate,T1608.004:Drive-by Target,T1608.005:Link Target,T1608.006:SEO Poisoning"
"ResourceDevelopment|T1650|Acquire Access|"

# ═══ Initial Access (TA0001) ═══
"InitialAccess|T1189|Drive-by Compromise|"
"InitialAccess|T1190|Exploit Public-Facing Application|"
"InitialAccess|T1133|External Remote Services|"
"InitialAccess|T1200|Hardware Additions|"
"InitialAccess|T1566|Phishing|T1566.001:Spearphishing Attachment,T1566.002:Spearphishing Link,T1566.003:Spearphishing via Service,T1566.004:Spearphishing Voice"
"InitialAccess|T1091|Replication Through Removable Media|"
"InitialAccess|T1195|Supply Chain Compromise|T1195.001:Compromise Software Dependencies and Development Tools,T1195.002:Compromise Software Supply Chain,T1195.003:Compromise Hardware Supply Chain"
"InitialAccess|T1199|Trusted Relationship|"
"InitialAccess|T1078|Valid Accounts|T1078.001:Default Accounts,T1078.002:Domain Accounts,T1078.003:Local Accounts,T1078.004:Cloud Accounts"

# ═══ Execution (TA0002) ═══
"Execution|T1059|Command and Scripting Interpreter|T1059.001:PowerShell,T1059.002:AppleScript,T1059.003:Windows Command Shell,T1059.004:Unix Shell,T1059.005:Visual Basic,T1059.006:Python,T1059.007:JavaScript,T1059.008:Network Device CLI,T1059.009:Cloud API,T1059.010:AutoHotKey and AutoIT"
"Execution|T1203|Exploitation for Client Execution|"
"Execution|T1559|Inter-Process Communication|T1559.001:Component Object Model,T1559.002:Dynamic Data Exchange,T1559.003:XPC Services"
"Execution|T1106|Native API|"
"Execution|T1053|Scheduled Task Job|T1053.002:At,T1053.003:Cron,T1053.005:Scheduled Task,T1053.006:Systemd Timers,T1053.007:Container Orchestration Job"
"Execution|T1129|Shared Modules|"
"Execution|T1072|Software Deployment Tools|"
"Execution|T1569|System Services|T1569.001:Launchctl,T1569.002:Service Execution"
"Execution|T1204|User Execution|T1204.001:Malicious Link,T1204.002:Malicious File,T1204.003:Malicious Image"
"Execution|T1047|Windows Management Instrumentation|"

# ═══ Persistence (TA0003) ═══
"Persistence|T1098|Account Manipulation|T1098.001:Additional Cloud Credentials,T1098.002:Additional Email Delegate Permissions,T1098.003:Additional Cloud Roles,T1098.004:SSH Authorized Keys,T1098.005:Device Registration,T1098.006:Additional Container Cluster Roles"
"Persistence|T1197|BITS Jobs|"
"Persistence|T1547|Boot or Logon Autostart Execution|T1547.001:Registry Run Keys Startup Folder,T1547.002:Authentication Package,T1547.003:Time Providers,T1547.004:Winlogon Helper DLL,T1547.005:Security Support Provider,T1547.006:Kernel Modules and Extensions,T1547.007:Re-opened Applications,T1547.008:LSASS Driver,T1547.009:Shortcut Modification,T1547.010:Port Monitors,T1547.012:Print Processors,T1547.013:XDG Autostart Entries,T1547.014:Active Setup,T1547.015:Login Items"
"Persistence|T1037|Boot or Logon Initialization Scripts|T1037.001:Logon Script Windows,T1037.002:Login Hook,T1037.003:Network Logon Script,T1037.004:RC Scripts,T1037.005:Startup Items"
"Persistence|T1176|Browser Extensions|"
"Persistence|T1554|Compromise Client Software Binary|"
"Persistence|T1136|Create Account|T1136.001:Local Account,T1136.002:Domain Account,T1136.003:Cloud Account"
"Persistence|T1543|Create or Modify System Process|T1543.001:Launch Agent,T1543.002:Systemd Service,T1543.003:Windows Service,T1543.004:Launch Daemon,T1543.005:Container Service"
"Persistence|T1546|Event Triggered Execution|T1546.001:Change Default File Association,T1546.002:Screensaver,T1546.003:WMI Event Subscription,T1546.004:Unix Shell Configuration Modification,T1546.005:Trap,T1546.006:LC_LOAD_DYLIB Addition,T1546.007:Netsh Helper DLL,T1546.008:Accessibility Features,T1546.009:AppCert DLLs,T1546.010:AppInit DLLs,T1546.011:Application Shimming,T1546.012:Image File Execution Options Injection,T1546.013:PowerShell Profile,T1546.014:Emond,T1546.015:Component Object Model Hijacking,T1546.016:Installer Packages"
"Persistence|T1133|External Remote Services|"
"Persistence|T1574|Hijack Execution Flow|T1574.001:DLL Search Order Hijacking,T1574.002:DLL Side-Loading,T1574.004:Dylib Hijacking,T1574.005:Executable Installer File Permissions Weakness,T1574.006:Dynamic Linker Hijacking,T1574.007:Path Interception by PATH Environment Variable,T1574.008:Path Interception by Search Order Hijacking,T1574.009:Path Interception by Unquoted Path,T1574.010:Services File Permissions Weakness,T1574.011:Services Registry Permissions Weakness,T1574.012:COR_PROFILER,T1574.013:KernelCallbackTable,T1574.014:AppDomainManager"
"Persistence|T1525|Implant Internal Image|"
"Persistence|T1556|Modify Authentication Process|T1556.001:Domain Controller Authentication,T1556.002:Password Filter DLL,T1556.003:Pluggable Authentication Modules,T1556.004:Network Device Authentication,T1556.005:Reversible Encryption,T1556.006:Multi-Factor Authentication,T1556.007:Hybrid Identity,T1556.008:Network Provider DLL,T1556.009:Conditional Access Policies"
"Persistence|T1137|Office Application Startup|T1137.001:Office Template Macros,T1137.002:Office Test,T1137.003:Outlook Forms,T1137.004:Outlook Home Page,T1137.005:Outlook Rules,T1137.006:Add-ins"
"Persistence|T1542|Pre-OS Boot|T1542.001:System Firmware,T1542.002:Component Firmware,T1542.003:Bootkit,T1542.004:ROMMONkit,T1542.005:TFTP Boot"
"Persistence|T1053|Scheduled Task Job|T1053.002:At,T1053.003:Cron,T1053.005:Scheduled Task,T1053.006:Systemd Timers,T1053.007:Container Orchestration Job"
"Persistence|T1505|Server Software Component|T1505.001:SQL Stored Procedures,T1505.002:Transport Agent,T1505.003:Web Shell,T1505.004:IIS Components,T1505.005:Terminal Services DLL"
"Persistence|T1205|Traffic Signaling|T1205.001:Port Knocking,T1205.002:Socket Filters"
"Persistence|T1078|Valid Accounts|T1078.001:Default Accounts,T1078.002:Domain Accounts,T1078.003:Local Accounts,T1078.004:Cloud Accounts"

# ═══ Privilege Escalation (TA0004) ═══
"PrivilegeEscalation|T1548|Abuse Elevation Control Mechanism|T1548.001:Setuid and Setgid,T1548.002:Bypass User Account Control,T1548.003:Sudo and Sudo Caching,T1548.004:Elevated Execution with Prompt,T1548.005:Temporary Elevated Cloud Access,T1548.006:TCC Manipulation"
"PrivilegeEscalation|T1134|Access Token Manipulation|T1134.001:Token Impersonation Theft,T1134.002:Create Process with Token,T1134.003:Make and Impersonate Token,T1134.004:Parent PID Spoofing,T1134.005:SID-History Injection"
"PrivilegeEscalation|T1547|Boot or Logon Autostart Execution|T1547.001:Registry Run Keys Startup Folder,T1547.002:Authentication Package,T1547.003:Time Providers,T1547.004:Winlogon Helper DLL,T1547.005:Security Support Provider,T1547.006:Kernel Modules and Extensions,T1547.007:Re-opened Applications,T1547.008:LSASS Driver,T1547.009:Shortcut Modification,T1547.010:Port Monitors,T1547.012:Print Processors,T1547.013:XDG Autostart Entries,T1547.014:Active Setup,T1547.015:Login Items"
"PrivilegeEscalation|T1037|Boot or Logon Initialization Scripts|T1037.001:Logon Script Windows,T1037.002:Login Hook,T1037.003:Network Logon Script,T1037.004:RC Scripts,T1037.005:Startup Items"
"PrivilegeEscalation|T1543|Create or Modify System Process|T1543.001:Launch Agent,T1543.002:Systemd Service,T1543.003:Windows Service,T1543.004:Launch Daemon,T1543.005:Container Service"
"PrivilegeEscalation|T1484|Domain or Tenant Policy Modification|T1484.001:Group Policy Modification,T1484.002:Domain Trust Modification"
"PrivilegeEscalation|T1546|Event Triggered Execution|T1546.001:Change Default File Association,T1546.002:Screensaver,T1546.003:WMI Event Subscription,T1546.004:Unix Shell Configuration Modification,T1546.005:Trap,T1546.006:LC_LOAD_DYLIB Addition,T1546.007:Netsh Helper DLL,T1546.008:Accessibility Features,T1546.009:AppCert DLLs,T1546.010:AppInit DLLs,T1546.011:Application Shimming,T1546.012:Image File Execution Options Injection,T1546.013:PowerShell Profile,T1546.014:Emond,T1546.015:Component Object Model Hijacking,T1546.016:Installer Packages"
"PrivilegeEscalation|T1068|Exploitation for Privilege Escalation|"
"PrivilegeEscalation|T1574|Hijack Execution Flow|T1574.001:DLL Search Order Hijacking,T1574.002:DLL Side-Loading,T1574.004:Dylib Hijacking,T1574.005:Executable Installer File Permissions Weakness,T1574.006:Dynamic Linker Hijacking,T1574.007:Path Interception by PATH Environment Variable,T1574.008:Path Interception by Search Order Hijacking,T1574.009:Path Interception by Unquoted Path,T1574.010:Services File Permissions Weakness,T1574.011:Services Registry Permissions Weakness,T1574.012:COR_PROFILER,T1574.013:KernelCallbackTable,T1574.014:AppDomainManager"
"PrivilegeEscalation|T1055|Process Injection|T1055.001:Dynamic-link Library Injection,T1055.002:Portable Executable Injection,T1055.003:Thread Execution Hijacking,T1055.004:Asynchronous Procedure Call,T1055.005:Thread Local Storage,T1055.008:Ptrace System Calls,T1055.009:Proc Memory,T1055.011:Extra Window Memory Injection,T1055.012:Process Hollowing,T1055.013:Process Doppelganging,T1055.014:VDSO Hijacking,T1055.015:ListPlanting"
"PrivilegeEscalation|T1053|Scheduled Task Job|T1053.002:At,T1053.003:Cron,T1053.005:Scheduled Task,T1053.006:Systemd Timers,T1053.007:Container Orchestration Job"
"PrivilegeEscalation|T1078|Valid Accounts|T1078.001:Default Accounts,T1078.002:Domain Accounts,T1078.003:Local Accounts,T1078.004:Cloud Accounts"

# ═══ Defense Evasion (TA0005) ═══
"DefenseEvasion|T1548|Abuse Elevation Control Mechanism|T1548.001:Setuid and Setgid,T1548.002:Bypass User Account Control,T1548.003:Sudo and Sudo Caching,T1548.004:Elevated Execution with Prompt,T1548.005:Temporary Elevated Cloud Access,T1548.006:TCC Manipulation"
"DefenseEvasion|T1134|Access Token Manipulation|T1134.001:Token Impersonation Theft,T1134.002:Create Process with Token,T1134.003:Make and Impersonate Token,T1134.004:Parent PID Spoofing,T1134.005:SID-History Injection"
"DefenseEvasion|T1197|BITS Jobs|"
"DefenseEvasion|T1612|Build Image on Host|"
"DefenseEvasion|T1622|Debugger Evasion|"
"DefenseEvasion|T1140|Deobfuscate Decode Files or Information|"
"DefenseEvasion|T1610|Deploy Container|"
"DefenseEvasion|T1006|Direct Volume Access|"
"DefenseEvasion|T1484|Domain or Tenant Policy Modification|T1484.001:Group Policy Modification,T1484.002:Domain Trust Modification"
"DefenseEvasion|T1480|Execution Guardrails|T1480.001:Environmental Keying"
"DefenseEvasion|T1211|Exploitation for Defense Evasion|"
"DefenseEvasion|T1222|File and Directory Permissions Modification|T1222.001:Windows File and Directory Permissions Modification,T1222.002:Linux and Mac File and Directory Permissions Modification"
"DefenseEvasion|T1564|Hide Artifacts|T1564.001:Hidden Files and Directories,T1564.002:Hidden Users,T1564.003:Hidden Window,T1564.004:NTFS File Attributes,T1564.005:Hidden File System,T1564.006:Run Virtual Instance,T1564.007:VBA Stomping,T1564.008:Email Hiding Rules,T1564.009:Resource Forking,T1564.010:Process Argument Spoofing,T1564.011:Ignore Process Interrupts"
"DefenseEvasion|T1574|Hijack Execution Flow|T1574.001:DLL Search Order Hijacking,T1574.002:DLL Side-Loading,T1574.004:Dylib Hijacking,T1574.005:Executable Installer File Permissions Weakness,T1574.006:Dynamic Linker Hijacking,T1574.007:Path Interception by PATH Environment Variable,T1574.008:Path Interception by Search Order Hijacking,T1574.009:Path Interception by Unquoted Path,T1574.010:Services File Permissions Weakness,T1574.011:Services Registry Permissions Weakness,T1574.012:COR_PROFILER,T1574.013:KernelCallbackTable,T1574.014:AppDomainManager"
"DefenseEvasion|T1562|Impair Defenses|T1562.001:Disable or Modify Tools,T1562.002:Disable Windows Event Logging,T1562.003:Impair Command History Logging,T1562.004:Disable or Modify System Firewall,T1562.006:Indicator Blocking,T1562.007:Disable or Modify Cloud Firewall,T1562.008:Disable or Modify Cloud Logs,T1562.009:Safe Mode Boot,T1562.010:Downgrade Attack,T1562.011:Spoof Security Alerting,T1562.012:Disable or Modify Linux Audit System"
"DefenseEvasion|T1070|Indicator Removal|T1070.001:Clear Windows Event Logs,T1070.002:Clear Linux or Mac System Logs,T1070.003:Clear Command History,T1070.004:File Deletion,T1070.005:Network Share Connection Removal,T1070.006:Timestomp,T1070.007:Clear Network Connection History and Configurations,T1070.008:Clear Mailbox Data,T1070.009:Clear Persistence"
"DefenseEvasion|T1202|Indirect Command Execution|"
"DefenseEvasion|T1036|Masquerading|T1036.001:Invalid Code Signature,T1036.002:Right-to-Left Override,T1036.003:Rename System Utilities,T1036.004:Masquerade Task or Service,T1036.005:Match Legitimate Name or Location,T1036.006:Space after Filename,T1036.007:Double File Extension,T1036.008:Masquerade File Type,T1036.009:Break Process Trees"
"DefenseEvasion|T1556|Modify Authentication Process|T1556.001:Domain Controller Authentication,T1556.002:Password Filter DLL,T1556.003:Pluggable Authentication Modules,T1556.004:Network Device Authentication,T1556.005:Reversible Encryption,T1556.006:Multi-Factor Authentication,T1556.007:Hybrid Identity,T1556.008:Network Provider DLL,T1556.009:Conditional Access Policies"
"DefenseEvasion|T1578|Modify Cloud Compute Infrastructure|T1578.001:Create Snapshot,T1578.002:Create Cloud Instance,T1578.003:Delete Cloud Instance,T1578.004:Revert Cloud Instance,T1578.005:Modify Cloud Compute Configurations"
"DefenseEvasion|T1112|Modify Registry|"
"DefenseEvasion|T1601|Modify System Image|T1601.001:Patch System Image,T1601.002:Downgrade System Image"
"DefenseEvasion|T1599|Network Boundary Bridging|T1599.001:Network Address Translation Traversal"
"DefenseEvasion|T1027|Obfuscated Files or Information|T1027.001:Binary Padding,T1027.002:Software Packing,T1027.003:Steganography,T1027.004:Compile After Delivery,T1027.005:Indicator Removal from Tools,T1027.006:HTML Smuggling,T1027.007:Dynamic API Resolution,T1027.008:Stripped Payloads,T1027.009:Embedded Payloads,T1027.010:Command Obfuscation,T1027.011:Fileless Storage,T1027.012:LNK Icon Smuggling,T1027.013:Encrypted Encoded File"
"DefenseEvasion|T1647|Plist File Modification|"
"DefenseEvasion|T1542|Pre-OS Boot|T1542.001:System Firmware,T1542.002:Component Firmware,T1542.003:Bootkit,T1542.004:ROMMONkit,T1542.005:TFTP Boot"
"DefenseEvasion|T1055|Process Injection|T1055.001:Dynamic-link Library Injection,T1055.002:Portable Executable Injection,T1055.003:Thread Execution Hijacking,T1055.004:Asynchronous Procedure Call,T1055.005:Thread Local Storage,T1055.008:Ptrace System Calls,T1055.009:Proc Memory,T1055.011:Extra Window Memory Injection,T1055.012:Process Hollowing,T1055.013:Process Doppelganging,T1055.014:VDSO Hijacking,T1055.015:ListPlanting"
"DefenseEvasion|T1620|Reflective Code Loading|"
"DefenseEvasion|T1207|Rogue Domain Controller|"
"DefenseEvasion|T1014|Rootkit|"
"DefenseEvasion|T1553|Subvert Trust Controls|T1553.001:Gatekeeper Bypass,T1553.002:Code Signing,T1553.003:SIP and Trust Provider Hijacking,T1553.004:Install Root Certificate,T1553.005:Mark-of-the-Web Bypass,T1553.006:Code Signing Policy Modification"
"DefenseEvasion|T1218|System Binary Proxy Execution|T1218.001:Compiled HTML File,T1218.002:Control Panel,T1218.003:CMSTP,T1218.004:InstallUtil,T1218.005:Mshta,T1218.007:Msiexec,T1218.008:Odbcconf,T1218.009:Regsvcs Regasm,T1218.010:Regsvr32,T1218.011:Rundll32,T1218.012:Verclsid,T1218.013:Mavinject,T1218.014:MMC,T1218.015:Electron Applications"
"DefenseEvasion|T1216|System Script Proxy Execution|T1216.001:PubPrn,T1216.002:SyncAppvPublishingServer"
"DefenseEvasion|T1221|Template Injection|"
"DefenseEvasion|T1205|Traffic Signaling|T1205.001:Port Knocking,T1205.002:Socket Filters"
"DefenseEvasion|T1127|Trusted Developer Utilities Proxy Execution|T1127.001:MSBuild"
"DefenseEvasion|T1535|Unused Unsupported Cloud Regions|"
"DefenseEvasion|T1550|Use Alternate Authentication Material|T1550.001:Application Access Token,T1550.002:Pass the Hash,T1550.003:Pass the Ticket,T1550.004:Web Session Cookie"
"DefenseEvasion|T1078|Valid Accounts|T1078.001:Default Accounts,T1078.002:Domain Accounts,T1078.003:Local Accounts,T1078.004:Cloud Accounts"
"DefenseEvasion|T1497|Virtualization Sandbox Evasion|T1497.001:System Checks,T1497.002:User Activity Based Checks,T1497.003:Time Based Evasion"
"DefenseEvasion|T1600|Weaken Encryption|T1600.001:Reduce Key Space,T1600.002:Disable Crypto Hardware"
"DefenseEvasion|T1220|XSL Script Processing|"

# ═══ Credential Access (TA0006) ═══
"CredentialAccess|T1557|Adversary-in-the-Middle|T1557.001:LLMNR NBT-NS Poisoning and SMB Relay,T1557.002:ARP Cache Poisoning,T1557.003:DHCP Spoofing"
"CredentialAccess|T1110|Brute Force|T1110.001:Password Guessing,T1110.002:Password Cracking,T1110.003:Password Spraying,T1110.004:Credential Stuffing"
"CredentialAccess|T1555|Credentials from Password Stores|T1555.001:Keychain,T1555.002:Securityd Memory,T1555.003:Credentials from Web Browsers,T1555.004:Windows Credential Manager,T1555.005:Password Managers,T1555.006:Cloud Secrets Management Stores"
"CredentialAccess|T1212|Exploitation for Credential Access|"
"CredentialAccess|T1187|Forced Authentication|"
"CredentialAccess|T1606|Forge Web Credentials|T1606.001:Web Cookies,T1606.002:SAML Tokens"
"CredentialAccess|T1056|Input Capture|T1056.001:Keylogging,T1056.002:GUI Input Capture,T1056.003:Web Portal Capture,T1056.004:Credential API Hooking"
"CredentialAccess|T1556|Modify Authentication Process|T1556.001:Domain Controller Authentication,T1556.002:Password Filter DLL,T1556.003:Pluggable Authentication Modules,T1556.004:Network Device Authentication,T1556.005:Reversible Encryption,T1556.006:Multi-Factor Authentication,T1556.007:Hybrid Identity,T1556.008:Network Provider DLL,T1556.009:Conditional Access Policies"
"CredentialAccess|T1111|Multi-Factor Authentication Interception|"
"CredentialAccess|T1621|Multi-Factor Authentication Request Generation|"
"CredentialAccess|T1040|Network Sniffing|"
"CredentialAccess|T1003|OS Credential Dumping|T1003.001:LSASS Memory,T1003.002:Security Account Manager,T1003.003:NTDS,T1003.004:LSA Secrets,T1003.005:Cached Domain Credentials,T1003.006:DCSync,T1003.007:Proc Filesystem,T1003.008:etc passwd and etc shadow"
"CredentialAccess|T1528|Steal Application Access Token|"
"CredentialAccess|T1649|Steal or Forge Authentication Certificates|"
"CredentialAccess|T1558|Steal or Forge Kerberos Tickets|T1558.001:Golden Ticket,T1558.002:Silver Ticket,T1558.003:Kerberoasting,T1558.004:AS-REP Roasting"
"CredentialAccess|T1539|Steal Web Session Cookie|"
"CredentialAccess|T1552|Unsecured Credentials|T1552.001:Credentials In Files,T1552.002:Credentials in Registry,T1552.003:Bash History,T1552.004:Private Keys,T1552.005:Cloud Instance Metadata API,T1552.006:Group Policy Preferences,T1552.007:Container API,T1552.008:Chat Messages"

# ═══ Discovery (TA0007) ═══
"Discovery|T1087|Account Discovery|T1087.001:Local Account,T1087.002:Domain Account,T1087.003:Email Account,T1087.004:Cloud Account"
"Discovery|T1010|Application Window Discovery|"
"Discovery|T1217|Browser Information Discovery|"
"Discovery|T1580|Cloud Infrastructure Discovery|"
"Discovery|T1538|Cloud Service Dashboard|"
"Discovery|T1526|Cloud Service Discovery|"
"Discovery|T1619|Cloud Storage Object Discovery|"
"Discovery|T1613|Container and Resource Discovery|"
"Discovery|T1622|Debugger Evasion|"
"Discovery|T1482|Domain Trust Discovery|"
"Discovery|T1083|File and Directory Discovery|"
"Discovery|T1615|Group Policy Discovery|"
"Discovery|T1046|Network Service Discovery|"
"Discovery|T1135|Network Share Discovery|"
"Discovery|T1040|Network Sniffing|"
"Discovery|T1201|Password Policy Discovery|"
"Discovery|T1120|Peripheral Device Discovery|"
"Discovery|T1069|Permission Groups Discovery|T1069.001:Local Groups,T1069.002:Domain Groups,T1069.003:Cloud Groups"
"Discovery|T1057|Process Discovery|"
"Discovery|T1012|Query Registry|"
"Discovery|T1018|Remote System Discovery|"
"Discovery|T1518|Software Discovery|T1518.001:Security Software Discovery"
"Discovery|T1082|System Information Discovery|"
"Discovery|T1614|System Location Discovery|T1614.001:System Language Discovery"
"Discovery|T1016|System Network Configuration Discovery|T1016.001:Internet Connection Discovery"
"Discovery|T1049|System Network Connections Discovery|"
"Discovery|T1033|System Owner User Discovery|"
"Discovery|T1007|System Service Discovery|"
"Discovery|T1124|System Time Discovery|"
"Discovery|T1497|Virtualization Sandbox Evasion|T1497.001:System Checks,T1497.002:User Activity Based Checks,T1497.003:Time Based Evasion"

# ═══ Lateral Movement (TA0008) ═══
"LateralMovement|T1210|Exploitation of Remote Services|"
"LateralMovement|T1534|Internal Spearphishing|"
"LateralMovement|T1570|Lateral Tool Transfer|"
"LateralMovement|T1563|Remote Service Session Hijacking|T1563.001:SSH Hijacking,T1563.002:RDP Hijacking"
"LateralMovement|T1021|Remote Services|T1021.001:Remote Desktop Protocol,T1021.002:SMB Windows Admin Shares,T1021.003:Distributed Component Object Model,T1021.004:SSH,T1021.005:VNC,T1021.006:Windows Remote Management,T1021.007:Cloud Services,T1021.008:Direct Cloud VM Connections"
"LateralMovement|T1091|Replication Through Removable Media|"
"LateralMovement|T1072|Software Deployment Tools|"
"LateralMovement|T1080|Taint Shared Content|"
"LateralMovement|T1550|Use Alternate Authentication Material|T1550.001:Application Access Token,T1550.002:Pass the Hash,T1550.003:Pass the Ticket,T1550.004:Web Session Cookie"

# ═══ Collection (TA0009) ═══
"Collection|T1557|Adversary-in-the-Middle|T1557.001:LLMNR NBT-NS Poisoning and SMB Relay,T1557.002:ARP Cache Poisoning,T1557.003:DHCP Spoofing"
"Collection|T1560|Archive Collected Data|T1560.001:Archive via Utility,T1560.002:Archive via Library,T1560.003:Archive via Custom Method"
"Collection|T1123|Audio Capture|"
"Collection|T1119|Automated Collection|"
"Collection|T1185|Browser Session Hijacking|"
"Collection|T1115|Clipboard Data|"
"Collection|T1530|Data from Cloud Storage|"
"Collection|T1602|Data from Configuration Repository|T1602.001:SNMP MIB Dump,T1602.002:Network Device Configuration Dump"
"Collection|T1213|Data from Information Repositories|T1213.001:Confluence,T1213.002:Sharepoint,T1213.003:Code Repositories,T1213.004:Customer Relationship Management Software"
"Collection|T1005|Data from Local System|"
"Collection|T1039|Data from Network Shared Drive|"
"Collection|T1025|Data from Removable Media|"
"Collection|T1074|Data Staged|T1074.001:Local Data Staging,T1074.002:Remote Data Staging"
"Collection|T1114|Email Collection|T1114.001:Local Email Collection,T1114.002:Remote Email Collection,T1114.003:Email Forwarding Rule"
"Collection|T1056|Input Capture|T1056.001:Keylogging,T1056.002:GUI Input Capture,T1056.003:Web Portal Capture,T1056.004:Credential API Hooking"
"Collection|T1113|Screen Capture|"
"Collection|T1125|Video Capture|"

# ═══ Command and Control (TA0011) ═══
"CommandAndControl|T1071|Application Layer Protocol|T1071.001:Web Protocols,T1071.002:File Transfer Protocols,T1071.003:Mail Protocols,T1071.004:DNS"
"CommandAndControl|T1092|Communication Through Removable Media|"
"CommandAndControl|T1132|Data Encoding|T1132.001:Standard Encoding,T1132.002:Non-Standard Encoding"
"CommandAndControl|T1001|Data Obfuscation|T1001.001:Junk Data,T1001.002:Steganography,T1001.003:Protocol or Service Impersonation"
"CommandAndControl|T1568|Dynamic Resolution|T1568.001:Fast Flux DNS,T1568.002:Domain Generation Algorithms,T1568.003:DNS Calculation"
"CommandAndControl|T1573|Encrypted Channel|T1573.001:Symmetric Cryptography,T1573.002:Asymmetric Cryptography"
"CommandAndControl|T1008|Fallback Channels|"
"CommandAndControl|T1105|Ingress Tool Transfer|"
"CommandAndControl|T1104|Multi-Stage Channels|"
"CommandAndControl|T1095|Non-Application Layer Protocol|"
"CommandAndControl|T1571|Non-Standard Port|"
"CommandAndControl|T1572|Protocol Tunneling|"
"CommandAndControl|T1090|Proxy|T1090.001:Internal Proxy,T1090.002:External Proxy,T1090.003:Multi-hop Proxy,T1090.004:Domain Fronting"
"CommandAndControl|T1219|Remote Access Software|"
"CommandAndControl|T1205|Traffic Signaling|T1205.001:Port Knocking,T1205.002:Socket Filters"
"CommandAndControl|T1102|Web Service|T1102.001:Dead Drop Resolver,T1102.002:Bidirectional Communication,T1102.003:One-Way Communication"

# ═══ Exfiltration (TA0010) ═══
"Exfiltration|T1020|Automated Exfiltration|T1020.001:Traffic Duplication"
"Exfiltration|T1030|Data Transfer Size Limits|"
"Exfiltration|T1048|Exfiltration Over Alternative Protocol|T1048.001:Exfiltration Over Symmetric Encrypted Non-C2 Protocol,T1048.002:Exfiltration Over Asymmetric Encrypted Non-C2 Protocol,T1048.003:Exfiltration Over Unencrypted Non-C2 Protocol"
"Exfiltration|T1041|Exfiltration Over C2 Channel|"
"Exfiltration|T1011|Exfiltration Over Other Network Medium|T1011.001:Exfiltration Over Bluetooth"
"Exfiltration|T1052|Exfiltration Over Physical Medium|T1052.001:Exfiltration over USB"
"Exfiltration|T1567|Exfiltration Over Web Service|T1567.001:Exfiltration to Code Repository,T1567.002:Exfiltration to Cloud Storage,T1567.003:Exfiltration to Text Storage Sites,T1567.004:Exfiltration Over Webhook"
"Exfiltration|T1029|Scheduled Transfer|"
"Exfiltration|T1537|Transfer Data to Cloud Account|"

# ═══ Impact (TA0040) ═══
"Impact|T1531|Account Access Removal|"
"Impact|T1485|Data Destruction|"
"Impact|T1486|Data Encrypted for Impact|"
"Impact|T1565|Data Manipulation|T1565.001:Stored Data Manipulation,T1565.002:Transmitted Data Manipulation,T1565.003:Runtime Data Manipulation"
"Impact|T1491|Defacement|T1491.001:Internal Defacement,T1491.002:External Defacement"
"Impact|T1561|Disk Wipe|T1561.001:Disk Content Wipe,T1561.002:Disk Structure Wipe"
"Impact|T1499|Endpoint Denial of Service|T1499.001:OS Exhaustion Flood,T1499.002:Service Exhaustion Flood,T1499.003:Application Exhaustion Flood,T1499.004:Application or System Exploitation"
"Impact|T1495|Firmware Corruption|"
"Impact|T1490|Inhibit System Recovery|"
"Impact|T1498|Network Denial of Service|T1498.001:Direct Network Flood,T1498.002:Reflection Amplification"
"Impact|T1496|Resource Hijacking|"
"Impact|T1489|Service Stop|"
"Impact|T1529|System Shutdown Reboot|"
)

$created = 0
$skipped = 0

foreach ($line in $matrix) {
    $parts = $line.Split('|')
    $tactic = $parts[0]
    $techId = $parts[1]
    $techName = $parts[2]
    $subsRaw = $parts[3]

    $techDir = Join-Path $base "$tactic\$techId"
    if (-not (Test-Path $techDir)) {
        New-Item -ItemType Directory -Path $techDir -Force | Out-Null
    }

    if ([string]::IsNullOrWhiteSpace($subsRaw)) {
        # No sub-techniques — create technique-level file
        $filePath = Join-Path $techDir "$techId.js"
        if (-not (Test-Path $filePath)) {
            $content = @"
// $techId - $techName
// Tactic: $tactic
// Status: Placeholder - no DDM built yet

export default null;
"@
            Set-Content -Path $filePath -Value $content -Encoding UTF8
            $created++
        } else {
            $skipped++
        }
    } else {
        # Has sub-techniques — create a file for each
        $subs = $subsRaw.Split(',')
        foreach ($sub in $subs) {
            $subParts = $sub.Split(':')
            $subId = $subParts[0].Trim()
            $subName = $subParts[1].Trim()
            $filePath = Join-Path $techDir "$subId.js"
            if (-not (Test-Path $filePath)) {
                $content = @"
// $subId - $subName
// Parent: $techId - $techName
// Tactic: $tactic
// Status: Placeholder - no DDM built yet

export default null;
"@
                Set-Content -Path $filePath -Value $content -Encoding UTF8
                $created++
            } else {
                $skipped++
            }
        }
    }
}

Write-Host "Done. Created: $created files. Skipped (already exist): $skipped files."
